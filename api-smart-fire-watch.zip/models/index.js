const Logs = require('./Log');
const Camera = require('./Camera');

module.exports = {
  Logs,
  Camera
};
